# ja-netfilter 桌面版

基于 **Tauri 2 + Vue 3** 的跨平台桌面 GUI，用于管理 [ja-netfilter](https://github.com/ja-netfilter/ja-netfilter) Java agent 框架。
v0.2.0 参考 `ckey_script.ps1`（CodeKey Run）的安装语义全面重写，并换用 **Material Design 3** 单页界面。

> ⚠️ **使用须知**：ja-netfilter 是一个通用的 Java agent 框架，可用于调试、监控和扩展基于 JVM 的应用程序。请仅在您拥有合法授权的软件上使用；绕过付费授权可能违反软件服务条款及当地法律法规。

---

## v0.2.0 修复与变更

### 核心修复（针对 "processing of -javaagent failed" 致命崩溃）

| # | 问题（v0.1.x） | 修复（v0.2.0，仿 `ckey_script.ps1`） |
|---|----------------|--------------------------------------|
| 1 | `-javaagent:` 直接指向安装目录，路径含空格（`C:\Program Files\`、`F:\ja-netfilter Desktop\`）或 `\\?\` 前缀时 JVM 无法加载，IDE 启动即崩溃 | **安全目录部署**：启动时把 `lib.jar`、`config-jetbrains/`、`plugins-jetbrains/` 部署到无空格目录（Windows `%LOCALAPPDATA%\ja-netfilter-desktop\agent\`），vmoptions 永远指向干净路径；Windows 下 8.3 短路径兜底 + 引号兜底 |
| 2 | 旧的 `-javaagent` 行残留/写坏，反复重装越写越乱 | **安装前强制清理**（ckey 的 `Revert_Vm_Options`）：剥离目标 vmoptions 中**全部** `-javaagent:*.jar*` 行再追加新行 |
| 3 | `setx` 设置 `<PRODUCT>_VM_OPTIONS` 指向工作区文件，升级/换目录后失效，状态错乱 | **删除（而非设置）环境变量**（ckey 的 `Remove_Env`）：清理 User + Machine 两个作用域的残留变量，并广播 `WM_SETTINGCHANGE` |
| 4 | 产品检测链走的是一条从未生效的路径（`JetBrains/<id>/idea.vmoptions`），界面状态与真实 IDE 脱节 | **`.home` 发现链**（ckey 的 `Process_Vm_Options`）：`%LOCALAPPDATA%\JetBrains\<Product>\.home` → 真实安装目录 → `bin\*.vmoptions`（递归）+ Roaming 配置目录 `<prd>64.exe.vmoptions` |
| 5 | Windows 上 PowerShell 环境变量广播是内联脚本；安装/卸载同步执行冻结 UI | **PowerShell 核心逻辑**（`src-tauri/src/scripts/win_core.ps1`，JSON 契约通信）+ 全部安装/卸载命令 `spawn_blocking` 异步化；"全部安装"单次 PS 进程覆盖所有产品 |
| 6 | 前端监听的 `log://entry` 事件在 Rust 端从未发出，日志靠 2 秒轮询 | 日志事件真实推送（`logger.rs` 注入 AppHandle），新增 SUCCESS 级别 |
| 7 | `\\?\UNC\` 前缀剥离顺序错误 | `platform.rs` 先剥 `\\?\UNC\` 再剥 `\\?\` |

### UI 重构（Material Design 3）

- **单页应用**：移除 vue-router 与侧边栏，顶部 MD3 Tab 导航（总览 / 配置 / 日志 / 设置）。
- **MD3 设计系统**（`src/styles/md3.css`）：以品牌橙为种子的 tonal 色板、MD3 类型标尺、形状（圆角 4/8/12/16/28/full）、elevation 阴影、state layers（hover 8% / press 12%）、组件（filled/tonal/outlined/text 按钮、卡片、Tab、switch、chip、segmented、snackbar、dialog、progress、radio）。
- **明暗双主题**：跟随系统 + 手动切换，MD3 dark scheme 全套 token。
- **中英双语**（`src/i18n`）：对齐 `ckey_script.ps1` 的 key→{zh,en} 结构，默认跟随系统语言。
- **配置页合并**：插件配置（dns/power/url）与各产品真实 vmoptions 编辑器合并为一个 Tab，直接编辑 IDE 实际读取的文件。

---

## 目录结构

```
ja-netfilter-desktop/
├── src/                          # Vue 3 + Pinia（MD3 单页应用）
│   ├── components/               # App 四个 Tab：Overview / Config / Logs / Settings
│   │                             # + SnackbarHost、ConfirmDialog
│   ├── stores/                   # products / settings / logs / toast / license
│   │                             # / ui（主题+语言）/ confirm
│   ├── i18n/                     # 中英双语文案（ckey_script.ps1 同款结构）
│   ├── api/                      # invoke 调用的类型化封装
│   ├── types/                    # 与 Rust 端对应的共享类型
│   └── styles/md3.css            # Material Design 3 设计系统（明暗双主题）
├── src-tauri/
│   ├── src/
│   │   ├── main.rs / lib.rs      # 入口：日志事件注入 + agent 部署 + 命令注册
│   │   ├── agent_home.rs         # 安全目录部署（ckey 的 %PUBLIC%\.jb_run 思路）
│   │   ├── scripts/win_core.ps1  # Windows PowerShell 核心逻辑（JSON 契约）
│   │   ├── installer.rs          # 安装/卸载（Windows→PS；macOS/Linux→Rust 同语义）
│   │   ├── locate.rs             # .home 产品发现链（Rust 侧，检测+Unix 安装复用）
│   │   ├── products.rs           # 状态检测（Roaming > bin vmoptions）
│   │   ├── vmoptions.rs          # vmoptions 编辑（真实文件 / agent 模板）
│   │   ├── config.rs             # dns/power/url 配置读写（agent 安全目录）
│   │   ├── workspace.rs          # 全局路径状态（bundle_root / agent_root）
│   │   ├── platform.rs           # 平台差异 + 路径规范化（\\?\ 剥离、引号兜底）
│   │   └── logger.rs             # 内存日志 + log://entry 事件推送
│   ├── resources/                # 自带 lib.jar / plugins / configs / vmoptions
│   └── tauri.conf.json           # Tauri 2 配置（窗口跟随系统主题）
└── package.json
```

### 安装语义（Windows，`win_core.ps1`）

1. 应用启动时把 agent 运行时部署到 `%LOCALAPPDATA%\ja-netfilter-desktop\agent\`。
2. 点击安装后，PowerShell 核心对每个产品：
   - 删除 `<PRODUCT>_VM_OPTIONS` 环境变量（User + Machine）；
   - 经 `%LOCALAPPDATA%\JetBrains\<Product>\.home` 定位安装目录，收集 `bin\*.vmoptions`（递归）与 `%APPDATA%\JetBrains\<Product>\<prd>64.exe.vmoptions`；
   - 对每个目标文件：剥离全部 `-javaagent:*.jar*` 与 `-Dja.netfilter.name=*` 行，追加
     `-javaagent:<安全目录>/lib.jar=jetbrains`（可选 `-Dja.netfilter.name=<授权名称>`）；
   - 广播 `WM_SETTINGCHANGE`。
3. 结果以 JSON 返回 Rust 层，操作日志实时推送到前端日志页。

macOS / Linux 走 `installer.rs` 的 Rust 原生实现，语义一致（`launchctl unsetenv`、shell rc 清理、同样的 `.home` 发现链）。

---

## 环境要求

| 工具 | 版本 | 说明 |
|------|------|------|
| Node.js | ≥ 20 LTS | Vue 3 前端 |
| pnpm | ≥ 9 | 包管理（corepack enable） |
| Rust | ≥ 1.77（stable） | Tauri 后端 |
| Tauri 2 系统依赖 | — | Linux 需 webkit2gtk-4.1 等，参见 [Tauri 前置条件](https://v2.tauri.app/start/prerequisites/) |

## 开发

```bash
corepack enable
corepack prepare pnpm@9 --activate

pnpm install
pnpm tauri:dev      # 开发（Vite 热更新 + Tauri）
pnpm tauri:build    # 构建 Windows/macOS/Linux 安装包
```

## PowerShell 核心的开发调试

`win_core.ps1` 输出契约：stdout 仅一行 JSON：

```json
{ "ok": true, "mode": "install", "results": [...], "logs": [{"level","message"}...] }
```

可脱离应用单独验证（Linux/macOS 上装 PowerShell 7 即可）：

```bash
# 伪造 JetBrains 目录后端到端测试
LOCALAPPDATA=/tmp/jbtest/local APPDATA=/tmp/jbtest/roaming \
  pwsh -File src-tauri/src/scripts/win_core.ps1 -Mode install \
  -Products "idea" -AgentJar /tmp/jbtest/agent/lib.jar -LicenseName "your-name"
```

> ⚠️ 注意：脚本内**不要**用与 `[string]$Products` 参数仅大小写不同的变量名（如
> `$products`）——PowerShell 变量大小写不敏感且参数带类型约束，数组赋值会被
> 静默空格 join 成字符串。
