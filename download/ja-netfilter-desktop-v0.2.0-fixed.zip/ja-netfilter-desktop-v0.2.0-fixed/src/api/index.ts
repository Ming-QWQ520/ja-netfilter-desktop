// Thin wrappers around the `invoke` calls that talk to the Rust backend.

import { invoke } from "@tauri-apps/api/core";
import type {
  ConfigFile,
  InstallResult,
  LogEntry,
  PluginJar,
  ProductInfo,
  WorkspaceInfo,
} from "@/types";

export const api = {
  // Products
  listProducts: () => invoke<ProductInfo[]>("list_products"),
  refreshProductStatus: (id: string) =>
    invoke<ProductInfo>("refresh_product_status", { productId: id }),

  // Install / Uninstall（异步命令；install/uninstall all 一次调用覆盖全部产品）
  installProduct: (id: string, licenseName?: string) =>
    invoke<InstallResult>("install_product", { productId: id, licenseName }),
  uninstallProduct: (id: string) =>
    invoke<InstallResult>("uninstall_product", { productId: id }),
  installAllProducts: (licenseName?: string) =>
    invoke<InstallResult[]>("install_all_products", { licenseName }),
  uninstallAllProducts: () =>
    invoke<InstallResult[]>("uninstall_all_products"),
  cleanupEnvVars: () => invoke<void>("cleanup_env_vars"),

  // vmoptions（path_or_id：绝对路径或产品 id）
  readVmoptions: (pathOrId: string) =>
    invoke<string>("read_vmoptions", { pathOrId }),
  writeVmoptions: (pathOrId: string, content: string) =>
    invoke<void>("write_vmoptions", { pathOrId, content }),
  resetVmoptions: (pathOrId: string) =>
    invoke<void>("reset_vmoptions", { pathOrId }),

  // Configs
  listConfigs: () => invoke<ConfigFile[]>("list_configs"),
  readConfig: (relativePath: string) =>
    invoke<string>("read_config", { relativePath }),
  writeConfig: (relativePath: string, content: string) =>
    invoke<string>("write_config", { relativePath, content }),
  resetConfig: (relativePath: string) =>
    invoke<void>("reset_config", { relativePath }),

  // Plugins
  readPluginJars: () => invoke<PluginJar[]>("read_plugin_jars"),

  // Workspace
  getWorkspaceInfo: () => invoke<WorkspaceInfo>("get_workspace_info"),
  revealInFinder: (path: string) =>
    invoke<void>("reveal_in_finder", { path }),

  // Logs
  getLogHistory: () => invoke<LogEntry[]>("get_log_history"),
  clearLogHistory: () => invoke<void>("clear_log_history"),

  // Misc
  appVersion: () => invoke<string>("app_version"),
};
