//! agent 运行时安全目录部署。
//!
//! 参考 `ckey_script.ps1` 的做法：它把 ja-netfilter.jar + config/ + plugins/
//! 放到 `%PUBLIC%\.jb_run\`——一个**保证无空格、可写、路径稳定**的目录，
//! 然后让 vmoptions 里的 `-javaagent:` 指向那里。这从根本上避免了
//! "安装路径含空格（C:\Program Files\、F:\ja-netfilter Desktop\）导致
//! processing of -javaagent failed" 的致命问题。
//!
//! 本应用等价实现：
//!   - Windows: `%LOCALAPPDATA%\ja-netfilter-desktop\agent\`
//!   - macOS:   `~/Library/ja-netfilter-desktop/agent\`（刻意避开含空格的
//!              "Application Support"）
//!   - Linux:   `~/.local/share/ja-netfilter-desktop/agent/`
//!
//! 每次应用启动时把 bundle 内的 `lib.jar`、`config-jetbrains/`、
//! `plugins-jetbrains/`、`vmoptions/` 同步过去（增量覆盖，总量 <1MB）。
//! Java agent 加载 jar 只需要读权限，插件/配置的用户编辑直接作用于该目录。

use std::fs;
use std::path::{Path, PathBuf};

use anyhow::{Context, Result};

use crate::platform;

/// agent 安全目录内的相对布局（目录名与 `-javaagent:...=jetbrains` 参数对应，
/// ja-netfilter 会从 lib.jar 同级的 `config-jetbrains/`、`plugins-jetbrains/`
/// 读取配置与插件）。
#[allow(dead_code)]
pub const AGENT_ITEMS: &[&str] = &[
    "lib.jar",
    "config-jetbrains",
    "plugins-jetbrains",
    "vmoptions",
];

/// 计算当前平台的 agent 安全目录。
pub fn agent_home() -> Result<PathBuf> {
    let base = match platform::Os::current() {
        platform::Os::Windows => dirs::data_local_dir()
            .context("无法解析 %LOCALAPPDATA% 目录")?,
        platform::Os::Macos => dirs::home_dir()
            .context("无法解析用户主目录")?
            .join("Library"),
        platform::Os::Linux => dirs::data_dir()
            .or_else(|| dirs::home_dir().map(|h| h.join(".local").join("share")))
            .context("无法解析 XDG data 目录")?,
    };
    Ok(base.join("ja-netfilter-desktop").join("agent"))
}

/// agent 安全目录是否"干净"（不含空白/非 ASCII——可直接写入 vmoptions）。
pub fn agent_home_is_clean(home: &Path) -> bool {
    platform::is_clean_agent_path(&platform::normalize_path_for_output(&home.join("lib.jar")))
}

/// 把 bundle 内资源同步到 agent 安全目录。
///
/// 返回 `(agent_root, is_clean)`：目录本身 + 路径是否可直接写入 vmoptions。
/// 同步策略：目录级全量镜像（先拷 lib.jar，再镜像三个目录）。
/// 资源总量 <1MB，启动时执行开销可忽略；覆盖式同步保证应用升级后
/// jar / 配置模板随之更新。
pub fn ensure_deployed(resource_root: &Path) -> Result<(PathBuf, bool)> {
    let home = agent_home()?;
    fs::create_dir_all(&home)
        .with_context(|| format!("创建 agent 安全目录失败：{}", home.display()))?;

    // 1. lib.jar
    let src_jar = resource_root.join("lib.jar");
    let dst_jar = home.join("lib.jar");
    if src_jar.exists() {
        fs::copy(&src_jar, &dst_jar).with_context(|| {
            format!(
                "复制 lib.jar 失败：{} -> {}",
                src_jar.display(),
                dst_jar.display()
            )
        })?;
    }

    // 2. 目录级镜像
    for dir in ["config-jetbrains", "plugins-jetbrains", "vmoptions"] {
        let src_dir = resource_root.join(dir);
        let dst_dir = home.join(dir);
        if src_dir.is_dir() {
            mirror_dir(&src_dir, &dst_dir)?;
        }
    }

    let clean = agent_home_is_clean(&home);
    Ok((home, clean))
}

/// 递归镜像目录：源侧存在则覆盖到目标，源侧不存在的目标文件保留
/// （用户对配置的自定义编辑不会在重装时丢失；模板更新通过覆盖生效）。
fn mirror_dir(src: &Path, dst: &Path) -> Result<()> {
    fs::create_dir_all(dst)?;
    for entry in fs::read_dir(src)?.flatten() {
        let sp = entry.path();
        let dp = dst.join(entry.file_name());
        if sp.is_dir() {
            mirror_dir(&sp, &dp)?;
        } else {
            fs::copy(&sp, &dp).with_context(|| {
                format!("复制资源失败：{} -> {}", sp.display(), dp.display())
            })?;
        }
    }
    Ok(())
}
