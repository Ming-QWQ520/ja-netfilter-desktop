//! 跨平台安装 / 卸载。
//!
//! v0.2.0 按 ckey_script.ps1 的语义全面重写：
//!   1. agent 永远指向部署到无空格安全目录的 lib.jar（agent_home::ensure_deployed）。
//!   2. 安装前剥离目标 vmoptions 中**全部**旧 `-javaagent:` 行（ckey 的
//!      Revert_Vm_Options，regex `^-javaagent:.*\.jar.*`），再追加新行 ——
//!      从根上治愈 "processing of -javaagent failed"。
//!   3. **删除**（而非设置）`<PRODUCT>_VM_OPTIONS` 环境变量（User + Machine
//!      两个作用域），并在 Windows 上广播 WM_SETTINGCHANGE —— 旧安装残留的
//!      环境变量不再可能指向失效文件。
//!   4. 目标文件 = IDE 真实读取的位置：Roaming 配置目录 vmoptions +
//!      `.home` 指向的安装目录 `bin/*.vmoptions`（递归）。
//!
//! Windows 上核心逻辑由内嵌的 `win_core.ps1` 完成（以 JSON 契约通信）；
//! macOS / Linux 由本模块以相同语义用 Rust 原生实现。

use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;

use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};

use crate::locate;
use crate::logger::{self, Level};
use crate::platform::{self, Os};
use crate::vmoptions;
use crate::workspace::WorkspaceState;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InstallResult {
    pub product_id: String,
    pub success: bool,
    /// 第一个编辑过的 vmoptions 文件（兼容旧字段）。
    pub vmoptions_path: Option<String>,
    /// 全部编辑/清理过的文件。
    pub edited_paths: Vec<String>,
    pub jar_path: String,
    pub message: String,
}

impl InstallResult {
    fn skip(product_id: &str, jar: &Path, message: String) -> Self {
        Self {
            product_id: product_id.to_string(),
            success: false,
            vmoptions_path: None,
            edited_paths: Vec::new(),
            jar_path: platform::normalize_path_for_output(jar),
            message,
        }
    }
}

fn result_from(product_id: &str, ok: bool, edited: Vec<PathBuf>, jar: &Path, message: &str) -> InstallResult {
    let disp: Vec<String> = edited
        .iter()
        .map(|p| platform::normalize_path_for_output(p))
        .collect();
    InstallResult {
        product_id: product_id.to_string(),
        success: ok,
        vmoptions_path: disp.first().cloned(),
        edited_paths: disp,
        jar_path: platform::normalize_path_for_output(jar),
        message: message.to_string(),
    }
}

// ---------------------------------------------------------------------------
// PowerShell 核心（Windows）
// ---------------------------------------------------------------------------

const WIN_CORE_PS1: &str = include_str!("scripts/win_core.ps1");

#[derive(Debug, Deserialize)]
struct PsLogEntry {
    level: String,
    message: String,
}

#[derive(Debug, Deserialize)]
struct PsProductResult {
    product: String,
    ok: bool,
    #[serde(default)]
    edited: Vec<String>,
    #[serde(default)]
    message: Option<String>,
}

#[derive(Debug, Deserialize)]
struct PsCoreOutput {
    ok: bool,
    #[serde(default)]
    results: Vec<PsProductResult>,
    #[serde(default)]
    logs: Vec<PsLogEntry>,
}

/// 把内嵌脚本写到临时文件（UTF-8 BOM 前缀，PS 5.1 才能正确解析 Unicode）。
fn materialize_ps_script() -> Result<PathBuf> {
    let dir = std::env::temp_dir().join("ja-netfilter-desktop");
    fs::create_dir_all(&dir)?;
    let path = dir.join("win_core.ps1");
    fs::write(&path, format!("\u{feff}{}", WIN_CORE_PS1))?;
    Ok(path)
}

/// 运行 PowerShell 核心，解析 JSON 输出，并把日志灌入应用日志。
fn run_ps_core(
    mode: &str,
    products: &[&str],
    agent_jar: &Path,
    license_name: Option<&str>,
) -> Result<PsCoreOutput> {
    let script = materialize_ps_script()?;
    let output = Command::new("powershell.exe")
        .args([
            "-NoProfile",
            "-NonInteractive",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
        ])
        .arg(&script)
        .arg("-Mode")
        .arg(mode)
        .arg("-Products")
        .arg(products.join(","))
        .arg("-AgentJar")
        .arg(agent_jar)
        .arg("-LicenseName")
        .arg(license_name.unwrap_or(""))
        .output()
        .context("无法启动 powershell.exe")?;

    let stdout = String::from_utf8_lossy(&output.stdout).to_string();
    let stderr = String::from_utf8_lossy(&output.stderr).to_string();

    // stdout 必须是纯 JSON；PS 把诊断信息写到 stderr
    let parsed: PsCoreOutput = serde_json::from_str(stdout.trim()).map_err(|e| {
        anyhow::anyhow!(
            "PowerShell 输出解析失败：{}；stderr: {}",
            e,
            stderr.trim()
        )
    })?;

    for log in &parsed.logs {
        let level = match log.level.as_str() {
            "error" => Level::Error,
            "warn" => Level::Warn,
            "success" => Level::Success,
            "debug" => Level::Debug,
            _ => Level::Info,
        };
        logger::append(level, &log.message);
    }

    Ok(parsed)
}

// ---------------------------------------------------------------------------
// macOS / Linux 原生实现（与 PS 同语义）
// ---------------------------------------------------------------------------

/// 剥离文件中全部受管行（-javaagent:*jar* / -Dja.netfilter.name=*），
/// 返回移除的行数。
fn strip_managed_lines(path: &Path) -> Result<usize> {
    let content = fs::read_to_string(path)
        .with_context(|| format!("读取 vmoptions 失败：{}", path.display()))?;
    let kept: Vec<&str> = content
        .lines()
        .filter(|l| !locate::is_agent_line(l) && !locate::is_name_line(l))
        .collect();
    let removed = content.lines().count() - kept.len();
    if removed > 0 {
        let mut out = kept.join("\n");
        if !out.is_empty() {
            out.push('\n');
        }
        fs::write(path, out)
            .with_context(|| format!("写入 vmoptions 失败：{}", path.display()))?;
        logger::append(
            Level::Info,
            &format!("已清理 {} 行旧 agent 配置：{}", removed, path.display()),
        );
    }
    Ok(removed)
}

/// 原生安装（Unix）：环境变量清理 + 定位 + 剥离 + 追加。
fn native_install(
    product_id: &str,
    agent_line: &str,
    name_line: Option<&str>,
) -> (bool, Vec<PathBuf>) {
    // 1. 删除旧环境变量（当前进程 + launchctl + shell rc）
    let env_var = platform::env_var_name(product_id);
    std::env::remove_var(&env_var);
    if Os::current() == Os::Macos {
        let _ = Command::new("launchctl").args(["unsetenv", &env_var]).status();
    }
    remove_from_shell_rc(&env_var);

    // 2. 定位
    let locations = locate::find_product_locations(product_id);
    let mut edited = Vec::new();

    for loc in &locations {
        for vm in loc.all_vmoptions() {
            if !vm.exists() {
                continue;
            }
            if let Err(e) = strip_managed_lines(&vm) {
                logger::append(Level::Error, &format!("{}：{}", vm.display(), e));
                continue;
            }
            match vmoptions::append_lines(&vm, agent_line, name_line) {
                Ok(()) => edited.push(vm),
                Err(e) => logger::append(Level::Error, &format!("{}：{}", vm.display(), e)),
            }
        }
    }

    (!edited.is_empty(), edited)
}

/// 原生卸载（Unix）。
fn native_uninstall(product_id: &str) -> Vec<PathBuf> {
    let env_var = platform::env_var_name(product_id);
    std::env::remove_var(&env_var);
    if Os::current() == Os::Macos {
        let _ = Command::new("launchctl").args(["unsetenv", &env_var]).status();
    }
    remove_from_shell_rc(&env_var);

    let mut cleaned = Vec::new();
    for loc in locate::find_product_locations(product_id) {
        for vm in loc.all_vmoptions() {
            if !vm.exists() {
                continue;
            }
            if let Ok(n) = strip_managed_lines(&vm) {
                if n > 0 {
                    cleaned.push(vm);
                }
            }
        }
    }
    cleaned
}

/// 从 ~/.profile、~/.bashrc、~/.zshrc 中移除 `<PRODUCT>_VM_OPTIONS=` 行。
fn remove_from_shell_rc(env_var: &str) {
    let marker = format!("{}_VM_OPTIONS=", env_var);
    for name in [".profile", ".bashrc", ".zshrc"] {
        let Some(home) = dirs::home_dir() else {
            continue;
        };
        let rc = home.join(name);
        let Ok(existing) = fs::read_to_string(&rc) else {
            continue;
        };
        let filtered: String = existing
            .lines()
            .filter(|l| !l.contains(&marker))
            .collect::<Vec<_>>()
            .join("\n");
        if filtered != existing {
            let _ = fs::write(&rc, filtered + "\n");
        }
    }
}

// ---------------------------------------------------------------------------
// 对外批量接口（命令层调用）
// ---------------------------------------------------------------------------

/// 批量安装（单产品或全部产品一次调用）。
/// Windows 上是一次 PowerShell 进程；Unix 上是原生循环。
pub fn install_batch(
    state: &WorkspaceState,
    product_ids: &[String],
    license_name: Option<&str>,
) -> Vec<InstallResult> {
    if product_ids.is_empty() {
        return Vec::new();
    }
    let refs: Vec<&str> = product_ids.iter().map(|s| s.as_str()).collect();

    // 重新确保 agent 已部署（幂等；用户可能手动删过 agent 目录）
    let jar = match crate::agent_home::ensure_deployed(&state.bundle_root) {
        Ok((jar, clean)) => {
            if !clean {
                logger::append(
                    Level::Warn,
                    &format!(
                        "agent 目录路径含空格/非 ASCII，安装时将启用短路径或引号兜底：{}",
                        jar.display()
                    ),
                );
            }
            jar
        }
        Err(e) => {
            logger::append(Level::Error, &format!("部署 agent 运行时失败：{}", e));
            return refs
                .iter()
                .map(|id| InstallResult::skip(id, &state.agent_jar, format!("部署失败：{}", e)))
                .collect();
        }
    };

    logger::append(
        Level::Info,
        &format!(
            "javaagent 将指向安全目录：{}",
            platform::normalize_path_for_output(&jar)
        ),
    );

    match Os::current() {
        Os::Windows => match run_ps_core("install", &refs, &jar, license_name) {
            Ok(out) if out.ok => out
                .results
                .into_iter()
                .map(|r| InstallResult {
                    product_id: r.product,
                    success: r.ok,
                    vmoptions_path: r.edited.first().cloned(),
                    edited_paths: r.edited,
                    jar_path: platform::normalize_path_for_output(&jar),
                    message: r.message.unwrap_or_default(),
                })
                .collect(),
            Ok(_) => refs
                .iter()
                .map(|id| InstallResult::skip(id, &jar, "PowerShell 执行失败".into()))
                .collect(),
            Err(e) => {
                logger::append(Level::Error, &format!("PowerShell 核心执行失败：{}", e));
                refs.iter()
                    .map(|id| InstallResult::skip(id, &jar, format!("{}", e)))
                    .collect()
            }
        },
        _ => {
            let agent_line = platform::javaagent_line(&jar);
            let name_line = license_name
                .map(|n| n.trim())
                .filter(|n| !n.is_empty())
                .map(|n| format!("-Dja.netfilter.name={}", n));

            let mut results = Vec::new();
            for id in &refs {
                let (ok, edited) = native_install(id, &agent_line, name_line.as_deref());
                if ok {
                    logger::append(
                        Level::Success,
                        &format!(
                            "[{}] 已安装 -> {}",
                            id,
                            edited
                                .iter()
                                .map(|p| platform::normalize_path_for_output(p))
                                .collect::<Vec<_>>()
                                .join(", ")
                        ),
                    );
                } else {
                    logger::append(
                        Level::Warn,
                        &format!("[{}] 未找到 IDE 的 vmoptions，已跳过", id),
                    );
                }
                results.push(result_from(id, ok, edited, &jar, ""));
            }
            results
        }
    }
}

/// 批量卸载。
pub fn uninstall_batch(state: &WorkspaceState, product_ids: &[String]) -> Vec<InstallResult> {
    if product_ids.is_empty() {
        return Vec::new();
    }
    let refs: Vec<&str> = product_ids.iter().map(|s| s.as_str()).collect();
    let jar = state.agent_jar.clone();

    match Os::current() {
        Os::Windows => match run_ps_core("uninstall", &refs, &jar, None) {
            Ok(out) if out.ok => out
                .results
                .into_iter()
                .map(|r| InstallResult {
                    product_id: r.product,
                    success: true,
                    vmoptions_path: r.edited.first().cloned(),
                    edited_paths: r.edited,
                    jar_path: platform::normalize_path_for_output(&jar),
                    message: r.message.unwrap_or_default(),
                })
                .collect(),
            _ => refs
                .iter()
                .map(|id| InstallResult::skip(id, &jar, "PowerShell 执行失败".into()))
                .collect(),
        },
        _ => {
            let mut results = Vec::new();
            for id in &refs {
                let cleaned = native_uninstall(id);
                logger::append(
                    Level::Success,
                    &format!("[{}] 已移除 javaagent（{} 处）", id, cleaned.len()),
                );
                results.push(result_from(id, true, cleaned, &jar, ""));
            }
            results
        }
    }
}

/// 仅清理环境变量。
pub fn cleanup_env(state: &WorkspaceState, product_ids: &[String]) {
    let refs: Vec<&str> = product_ids.iter().map(|s| s.as_str()).collect();
    let jar = state.agent_jar.clone();
    match Os::current() {
        Os::Windows => {
            let _ = run_ps_core("cleanup-env", &refs, &jar, None);
        }
        _ => {
            for id in refs {
                let env_var = platform::env_var_name(id);
                std::env::remove_var(&env_var);
                if Os::current() == Os::Macos {
                    let _ = Command::new("launchctl")
                        .args(["unsetenv", &env_var])
                        .status();
                }
                remove_from_shell_rc(&env_var);
            }
        }
    }
}
