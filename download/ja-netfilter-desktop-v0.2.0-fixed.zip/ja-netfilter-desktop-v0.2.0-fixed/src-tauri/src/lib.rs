//! ja-netfilter-desktop — Tauri application library entry point.
//!
//! v0.2.0 启动流程：
//!   1. env_logger 初始化
//!   2. 注入前端日志事件发送器（log://entry）
//!   3. 初始化工作区 + 定位 bundle 资源
//!   4. 把 agent 运行时部署到无空格安全目录（ckey_script.ps1 的 .jb_run 思路）
//!   5. 注册全部命令

mod agent_home;
mod commands;
mod config;
mod installer;
mod locate;
mod logger;
mod platform;
mod products;
mod vmoptions;
mod workspace;

use commands::*;
use tauri::Manager;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info"))
        .format_timestamp_secs()
        .init();

    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_os::init())
        .plugin(tauri_plugin_process::init())
        .plugin(tauri_plugin_shell::init())
        .setup(|app| {
            // 1. 前端实时日志事件
            logger::set_emitter(app.handle().clone());

            // 2. 工作区 + bundle 资源
            let (workdir, bundle_root) = workspace::init_workspace(app.handle())?;

            // 3. 部署 agent 运行时到无空格安全目录
            let (agent_root, agent_clean) = agent_home::ensure_deployed(&bundle_root)?;
            let agent_jar = agent_root.join("lib.jar");

            log::info!("bundle 资源目录：{}", bundle_root.display());
            log::info!("agent 安全目录：{}", agent_root.display());
            log::info!("agent lib.jar：{}", agent_jar.display());
            if !agent_clean {
                log::warn!(
                    "agent 路径含空格或非 ASCII 字符：{}（安装时将启用短路径/引号兜底）",
                    agent_jar.display()
                );
                logger::append(
                    logger::Level::Warn,
                    &format!(
                        "agent 路径含空格/非 ASCII，安装时将启用短路径兜底：{}",
                        agent_jar.display()
                    ),
                );
            }
            logger::append(
                logger::Level::Success,
                &format!(
                    "agent 运行时就绪：{}",
                    crate::platform::normalize_path_for_output(&agent_jar)
                ),
            );

            app.manage(workspace::WorkspaceState::new(
                workdir,
                bundle_root,
                agent_root,
                agent_jar,
            ));
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            list_products,
            refresh_product_status,
            install_product,
            uninstall_product,
            install_all_products,
            uninstall_all_products,
            cleanup_env_vars,
            read_vmoptions,
            write_vmoptions,
            reset_vmoptions,
            list_configs,
            read_config,
            write_config,
            reset_config,
            read_plugin_jars,
            get_workspace_info,
            reveal_in_finder,
            get_log_history,
            clear_log_history,
            app_version,
        ])
        .run(tauri::generate_context!())
        .expect("error while running ja-netfilter-desktop application");
}
